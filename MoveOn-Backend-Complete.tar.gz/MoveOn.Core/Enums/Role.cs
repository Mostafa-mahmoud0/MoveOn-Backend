namespace MoveOn.Core.Enums;

public enum Role
{
    User = 0,
    Admin = 1,
    Trainer = 2
}